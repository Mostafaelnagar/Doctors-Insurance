package com.company.doctorsinsurance;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.company.doctorsinsurance.common.common;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        View view = findViewById(android.R.id.content);
        common.navigationMenu(view, getBaseContext());
        common.changeToolbarSettings(view, R.mipmap.ic_, this.getResources().getString(R.string.insurance));
    }


}
