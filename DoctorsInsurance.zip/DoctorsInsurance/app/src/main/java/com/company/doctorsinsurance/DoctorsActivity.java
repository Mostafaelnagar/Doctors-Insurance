package com.company.doctorsinsurance;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.company.doctorsinsurance.common.common;

public class DoctorsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors);
        View view = findViewById(android.R.id.content);
        common.navigationMenu(view, getBaseContext());
        common.changeToolbarSettings(view, R.mipmap.ic_ask_doctors, this.getResources().getString(R.string.ask_doctors));

    }
}
