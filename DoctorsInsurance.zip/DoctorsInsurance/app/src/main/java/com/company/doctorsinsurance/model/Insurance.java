package com.company.doctorsinsurance.model;

public class Insurance {

}
